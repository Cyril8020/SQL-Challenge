Drop Table Departments;
Drop Table Department_employees;
Drop Table Department_Manager;
Drop Table Employees;
Drop Table Salaries;
Drop Table Titles;
CREATE TABLE Departments (
    "dept_no" VARCHAR   NOT NULL,
    "dept_name" VARCHAR   NOT NULL,
    Primary Key (dept_no)
);

CREATE TABLE Department_employees (
    "emp_no" Integer   NOT NULL,
    "dept_no" VARCHAR   NOT NULL,
    Foreign Key(emp_no) References Employees(emp_no),
	Foreign Key(dept_no) References Departments(dept_no),
	Primary Key(dept_no,emp_no)
);

CREATE TABLE Department_Manager (
    "dept_no" VARCHAR   NOT NULL,
    "emp_no" INTEGER   NOT NULL,
    Foreign Key(emp_no) References Employees(emp_no),
	Foreign Key(dept_no) References Departments(dept_no),
	Primary Key(dept_no,emp_no)
);

CREATE TABLE Employees (
    "emp_no" INTEGER   NOT NULL,
    "emp_title_id" VARCHAR   NOT NULL,
    "birth_date" DATE   NOT NULL,
    "first_name" VARCHAR   NOT NULL,
    "last_name" VARCHAR   NOT NULL,
    "sex" VARCHAR   NOT NULL,
    "hire_date" DATE   NOT NULL,
    Foreign Key (emp_title_id) References Titles(title_id),
	Primary Key (emp_no)
);

CREATE TABLE Salaries (
    "emp_no" INTEGER   NOT NULL,
    "salary" INTEGER   NOT NULL,
    Foreign Key (emp_no) References Employees (emp_no),
	Primary Key (emp_no)
);

CREATE TABLE Titles (
    "title_id" VARCHAR  NOT NULL,
    "title" VARCHAR   NOT NULL,
	Primary Key (title_id)
);

ALTER TABLE "Department_Manager" ADD CONSTRAINT "fk_Department_Manager_dept_no" FOREIGN KEY("dept_no")
REFERENCES "Departments" ("dept_no");

ALTER TABLE "Department_Manager" ADD CONSTRAINT "fk_Department_Manager_emp_no" FOREIGN KEY("emp_no")
REFERENCES "Employees" ("emp_no");

ALTER TABLE "Salaries" ADD CONSTRAINT "fk_Employees_emp_no" FOREIGN KEY("emp_no")
REFERENCES "Employees" ("emp_no");

ALTER TABLE "Department_employees" ADD CONSTRAINT "pk_dept_emp_np" PRIMARY KEY ("emp_no","dept_no")
