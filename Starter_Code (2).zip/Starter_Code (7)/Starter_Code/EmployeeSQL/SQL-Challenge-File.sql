Select Employees.emp_no , last_name, first_name, sex, salries.salary
From Employees
Join Salaries On Employees.emp_no = Salaries.emp_no

Select first_name , last_name, hire_date
From Employees
Where hire_date > 12/31/1985

Select dept_no, dept_name, Employees.first_name , Employees.last_name , Employees.emp_no 
From Departments
JOIN Employees ON Departments.dept_no = Employees.dept_no

Select dept_no , Employees.emp_no , Employees.last_name , Employees.first_name , dept_name
From Departments
JOIN Employees ON Departments.dept_no = Employees.dept_no
Order by dept_no

Select Employees.first_name , Employees.last_name , sex
From Employees
Where Employees.first_name = 'Hercules' AND Employees.last_name LIKE '%B'

Select emp_no, Employees.first_name , Employees.last_name,
From Department
JOIN Employees ON Departments.dept_no = Employees.dept_no
Where dept.no = 'd007'

Select emp_no, Employees.first_name , Employees.last_name,dept_name
From Department
JOIN Employees ON Departments.dept_no = Employees.dept_no
Where dept.no = 'd007' AND dept.no = 'd005'

